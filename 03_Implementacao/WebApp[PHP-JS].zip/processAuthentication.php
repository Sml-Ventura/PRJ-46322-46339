<?php
    // check if sessions has started
    if ( !isset($_SESSION) ) {
      session_start();
    }
    $sucessAuthURL = "list.php";
    $failedAuthURL = "authentication.php";
    
    // uses the session values if it already exists, otherwise chooses the inputs instead
    if( isset($_SESSION["s2f-credentials"]) ) {
        $username = $_SESSION["s2f-credentials"]['username'];
        $password = $_SESSION["s2f-credentials"]['password'];
    } else {
        // get the post values
        $_INPUT_METHOD = INPUT_POST;
        $flags[] = FILTER_NULL_ON_FAILURE;
        $username = filter_input( $_INPUT_METHOD, 'userInput', FILTER_SANITIZE_STRING, $flags);
        $password = filter_input( $_INPUT_METHOD, 'passwordInput', FILTER_SANITIZE_STRING, $flags);
    }
    echo "$username and $password";
    
    // import MongoDB 
    require_once("libs/importMongo.php");
    // instanciates a new client
    $client = new \MongoDB\Client(
        "mongodb+srv://".$username.":".$password."@clusterisel.ksoyd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
    
    
    // checks if the user is authenticated by performing a general query
    try {
        $client->listDatabaseNames();
    
        // starts a session with the user credentials
        $_SESSION["s2f-credentials"] = array(
            "username" => $username,
            "password" => $password
        );
        // sets the next url. If theres already a desired location saved in session, chooses that instead.
        if( isset($_SESSION["locationAfterAuth"]) ){
            $nextUrl = $_SESSION["locationAfterAuth"];
        } else {
            $nextUrl = $sucessAuthURL;
        }
    } catch(MongoDB\Driver\Exception\AuthenticationException $e) {
        // catches de failed authentication (bad auth) and redirects to the login page
        echo "<br> $e";
        $_SESSION["failed"] = true;
        $nextUrl = $failedAuthURL;
    }
        
    header("Location: ". $nextUrl);
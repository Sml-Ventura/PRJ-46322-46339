<?php
// check if sessions has started
if ( !isset($_SESSION) ) {
    session_start();
}

// import MongoDB 
require_once("libs/importMongo.php");    
// instanciates a new client
$username = $_SESSION["s2f-credentials"]['username'];
$password = $_SESSION["s2f-credentials"]['password'];
$client = new \MongoDB\Client(
        "mongodb+srv://".$username.":".$password."@clusterisel.ksoyd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
    
// get the document given via GET
$_INPUT_METHOD = INPUT_GET;
$flags[] = FILTER_NULL_ON_FAILURE;
$missionName = filter_input( $_INPUT_METHOD, 'document', FILTER_SANITIZE_STRING, $flags);
$missionId = filter_input( $_INPUT_METHOD, 'documentId', FILTER_SANITIZE_STRING, $flags);
    
// get the given collection from the database
$db = $client->BoatTelemetryDB;
$collection = $db->$missionName;
$documents  = $collection->find([], []);

require_once ('libs/PHPlot/phplot/phplot.php');
require_once ('utils/customPHPlots.php');

// 0: Bars Chart | 1: Pie Chart | 2: Line Chart
$plotType = filter_input( $_INPUT_METHOD, 'type', FILTER_SANITIZE_STRING, $flags);
$fromDoc = filter_input( $_INPUT_METHOD, 'from', FILTER_SANITIZE_STRING, $flags);
$toDoc = filter_input( $_INPUT_METHOD, 'to', FILTER_SANITIZE_STRING, $flags);
$dataType = filter_input( $_INPUT_METHOD, 'data', FILTER_SANITIZE_STRING, $flags);;

$data = getDataFromCollection($documents, $fromDoc, $toDoc, $plotType, $dataType);

$plot = new PHPlot(600, 300);
$plot->SetImageBorderType('plain');

switch($plotType) {
    case 0:
        $plot = plotBars($plot, $data);
        break;
    case 1:
        $plot = plotLines($plot, $data);
}

# Main plot title:
$plot->SetTitle("$missionName: Plot $dataType");
# Y Axis title:
$plot->SetYTitle("$dataType");
# Draws the plot:
$plot->DrawGraph();
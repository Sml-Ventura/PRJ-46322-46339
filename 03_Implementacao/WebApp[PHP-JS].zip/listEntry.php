<div id="mission" class="container row justify-content-between">
    <div id="remove-padding" class="col-3 text-center bg-info">
        <div id="map-<?php echo $missionName ?>" style="height:100%; width:auto;"></div>
    </div>
    <div id="info" class="col-9 mt-3 pl-3">
        <p id="subtitulo"><?php echo $missionName; ?><span>: <?php echo $missionCodename ?> </p></span></p>
        <div id="location" class="row my-1"> <i id="location-icon" class="fas fa-map-marker-alt mr-1"></i> <p id="location-name-<?php echo $missionName ?>"></p> </div>
        <p id="text-sm"> Ocorrida entre <span id="date-from"><?php echo $earliestDate ?></span> até <span id="date-from"><?php echo $latestDate ?></span>.<p>
        <p id="text-sm" class="mt-2 mb-2"> <?php echo $missionDescription ?> </p>
        <form action="<?php echo $nextUrl ?>" method="GET">
            <input name="document" value="<?php echo $missionName ?>" style="display:none"/>
            <div id="details-button" class="text-right">
                <button class="button" type="submit"><span>Ver detalhes</span></button>
            </div>
        </form>
    </div>
</div>
<div> 
    <?php
    // include OpenSeaMap using OpenLayers Framework
    require("utils/OSMOpenLayer.php");
    ?>
    <script type="text/javascript"> loadOpenLayersMap();</script>
</div>
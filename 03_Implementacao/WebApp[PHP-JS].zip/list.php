<!DOCTYPE html>
<?php
    // check if sessions has started
    if ( !isset($_SESSION) ) {
      session_start();
    }
    // editable variables
    $logoutURL = "logout.php";
    $nextUrl = "mission.php";

    // import MongoDB 
    require_once("libs/importMongo.php");    
    // instanciates a new client
    $username = $_SESSION["s2f-credentials"]['username'];
    $password = $_SESSION["s2f-credentials"]['password'];
    $client = new \MongoDB\Client(
        "mongodb+srv://".$username.":".$password."@clusterisel.ksoyd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
    
    // select a database
    $db = $client->BoatTelemetryDB;
    // get all collections (missions)
    $collections = $db -> listCollections();
    
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />    
    <meta charset="UTF-8">
    <link rel="stylesheet" href="res/css/list.css">
    <title>Lista de Missões</title>
    <?php require_once("scripts/imports.php"); ?>
</head>

<body>
    <!-- Container com os logotipos -->	
    <div id="imgHeader" class="text-center"> 
        <img src="res/imgs/logo_isel.png" class="img-fluid mr-3" alt="Isel Logo">
        <img src="res/imgs/logo_enidh.png" class="img-fluid ml-3" alt="Enidh Logo"> 
    </div>
    <!-- Seccao central -->
    <div id="center-space" class="d-flex justify-content-center align-items-center">
        <div id="center-card" class="container"> 
            <!-- Card central -->
            <div id="middle-card" class="pt-3 px-3">
                <!-- Header Card: titulo + logout -->
                <div id="top-card" class="container row justify-content-between">
                    <p id="titulo" class="col-6">Histórico de Viagens</p>
                    <div  id="userInfo" class="col-3 justify-content-center align-items-center text-right"> 
                        <p id="subtitulo-sm">Bem vindo 
                            <span id="username"><?php echo $_SESSION["s2f-credentials"]["username"] ?></span>  
                        </p>
                        <a href="<?php echo $logoutURL ?>">Logout</a>
                    </div>
                </div>
                <div id="scrollMenu" class="mt-3 mb-2">
                    <?php
                    foreach ($collections as $mission) {
                        $missionName = $mission->getName();
                        $collection = $db->$missionName;
                        // gets the earliest read
                        $earliestRead = $collection->findOne([], ['sort' => ['Timestamp' => 1]]);
                        $earliestDate = (new DateTime($earliestRead["Timestamp"]))->format('d/m/Y');
                        // gets the latest read
                        $latestRead = $collection->findOne([], ['sort' => ['Timestamp' => -1]]);
                        $latestDate = (new DateTime($latestRead["Timestamp"]))->format('d/m/Y');
                        // get GPS position based on earliest read
                        $osmZoom = 12;
                        $lat = $earliestRead["GPS"][0];
                        $lon = $earliestRead["GPS"][1];
                        // gets the document containing the codename (and description)
                        $data = $collection->findOne(["Codename" => array('$exists' => true)], []);
                        $missionCodename = $data["Codename"];
                        $missionDescription = $data["Description"];
                        // one collection entry of the list
                        require("listEntry.php");
                     } ?>
                </div>
                <p id="text-footer"> Sea2Future </p>
            </div>
            <!-- Container com os logotipos (view telemovel) -->
            <div id="imgFooter" class="d-flex row my-3 justify-content-center  align-items-center"> 
                <img src="res/imgs/logo_isel.png" class="img-fluid col-5" alt="Isel Logo">
                <img src="res/imgs/logo_enidh.png" class="img-fluid col-5" alt="Enidh Logo"> 
            </div>
        </div>
    </div>
</body>
</html>

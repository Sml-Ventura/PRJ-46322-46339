<?php
    // check if sessions has started
    if ( !isset($_SESSION) ) {
      session_start();
    }
    // editable variables
    $logoutURL = "logout.php";
    
    // include Decimal to DMS converter
    require_once("utils/decDmsFormat.php");  
    // import MongoDB 
    require_once("libs/importMongo.php");    
    // instanciates a new client
    $username = $_SESSION["s2f-credentials"]['username'];
    $password = $_SESSION["s2f-credentials"]['password'];
    $client = new \MongoDB\Client(
        "mongodb+srv://".$username.":".$password."@clusterisel.ksoyd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
    
    // get the document given via GET
    $_INPUT_METHOD = INPUT_GET;
    $flags[] = FILTER_NULL_ON_FAILURE;
    $missionName = filter_input( $_INPUT_METHOD, 'document', FILTER_SANITIZE_STRING, $flags);
    
    // get the given collection from the database
    $db = $client->BoatTelemetryDB;
    $collection = $db->$missionName;
    
    // collection parameters
    $osmZoom = 16;
    $gps = $collection->findOne(
            [], 
            ['sort' => ['Timestamp' => 1]])['GPS'];
    $lat = $gps[0];
    $lon = $gps[1];
    // gets the earliest read
    $earliestRead = $collection->findOne([], ['sort' => ['Timestamp' => 1]]);
    $earliestDate = (new DateTime($earliestRead["Timestamp"]))->format('d/m/Y');
    // gets the latest read
    $latestRead = $collection->findOne([], ['sort' => ['Timestamp' => -1]]);
    $latestDate = (new DateTime($latestRead["Timestamp"]))->format('d/m/Y');
    // gets the document containing the codename (and description)
    $data = $collection->findOne(["Codename" => array('$exists' => true)], []);
    $missionCodename = $data["Codename"];
    $missionDescription = $data["Description"];
?>
<!DOCTYPE html>

<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta charset="UTF-8">
        <link rel="stylesheet" href="res/css/mission.css">
        <title>Detalhes Missão</title>
        <?php require_once("scripts/imports.php"); ?>
    </head>
    
    <body onload="loadOpenLayersMap()">
        <!-- Container com os logotipos -->	
        <div id="imgHeader" class="text-center"> 
            <img src="res/imgs/logo_isel.png" class="img-fluid mr-3" alt="Isel Logo">
            <img src="res/imgs/logo_enidh.png" class="img-fluid ml-3" alt="Enidh Logo"> 
        </div>
        <!-- Seccao central -->
        <div id="center-space" class="d-flex justify-content-center align-items-center">
            <div id="center-card" class="container"> 
                <!-- Card central -->
                <div id="middle-card" class="pt-3 px-3">
                    <!-- Header Card: titulo + logout -->
                    <div id="top-card" class="container row justify-content-between">
                        <p id="titulo" class="col-6"><?php echo $missionName ?>: <?php echo $missionCodename ?></p>
                        <div  id="userInfo" class="col-3 justify-content-center align-items-center text-right"> 
                            <p id="subtitulo-sm">Bem vindo 
                                <span id="username">Admin</span>  
                            </p>
                            <a href="<?php echo $logoutURL ?>">Logout</a>
                        </div>
                        <div id="grey-background" class="row">
                            <!-- Table -->
                            <div id="scrollMenu" class="mt-3 mb-2 pl-3 col-12 col-md-7">
                                <table class="table table-bordered">
                                    <!-- Table Header -->
                                    <thead class="table-dark">
                                        <tr>
                                            <th scope="col">Data e Hora</th>
                                            <th scope="col">Posição Registada</th>
                                            <th scope="col"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Writes a new entry in the table for each codument in the collection -->
                                        <?php
                                        // for every document in the collection/mission
                                        $documents = $collection->find([], []);
                                        foreach ($documents as $document) {
                                            $documentId = $document["_id"];
                                            ?>
                                            <tr>
                                                <td id="remove-margin"> <?php echo (new DateTime($document["Timestamp"]))->format('d/m/Y H:i:s'); ?></td>
                                                <td id="remove-margin"> <?php echo lat_lng($document["GPS"][0], $document["GPS"][1]); ?></td>
                                                <td id="remove-margin-button">
                                                    <!-- Details link -->
                                                    <form action="detail.php?document=<?php echo $missionName ?>&documentId=<?php echo $documentId ?>" method="POST">
                                                        <button id="link-btn" type="submit" class="btn btn-link btn-md">Ver detalhes</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- Mission details -->
                            <div id="mission" class="container justify-content-between mt-3 mb-2 col-12 col-md-5">
                                <!--<img id="map-image" src="resources/temp.PNG" class="img-fluid text-center bg-info" alt="Image not found...">-->
                                <div id="map-<?php echo $missionName ?>" style="height:250px; width:100%;"></div> 
                                <div id="info" class="mt-3">
                                    <div id="location" class="row my-1"> <i id="location-icon" class="fas fa-map-marker-alt mr-1"></i> <p id="location-name-<?php echo $missionName ?>"></p> </div>
                                    <p id="text-sm">Ocorrida entre <span id="date-from"><?php echo $earliestDate ?></span> até <span id="date-from"><?php echo $latestDate ?></span>.<p>
                                        <b id="subtitulo">Descrição</b>
                                    <p id="text-sm" class="mt-2 mb-2"> <?php echo $missionDescription ?> </p>
                                </div>
                                <!-- Action Buttons (Save CSV and Delete) -->
                                <div id="remove-margin" class="row justify-content-between">  
                                    <!-- Save data as CSV file vutton -->
                                    <a href="processSaveColection.php?document=<?php echo $missionName ?>" class="btn btn-sm btn-success btn-outline text-white">
                                        <i class="fa fa-download fa-sm pr-2" aria-hidden="true"></i> Guardar coleção</a>
                                    <!-- Delete collection/mission button -->
                                    <a value="deleteMission" data-toggle="modal" data-target="#deleteModal" class="btn btn-sm btn-danger btn-outline text-white">
                                        <i class="fa fa-trash fa-sm pr-2" aria-hidden="true"></i> Apagar missão</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <p id="text-footer"> Sea2Future </p>
                </div>
            </div>
            <!-- Container com os logotipos (view telemovel) -->
            <div id="imgFooter" class="d-flex row my-3 justify-content-center  align-items-center"> 
                <img src="res/imgs/logo_isel.png" class="img-fluid col-5" alt="Isel Logo">
                <img src="res/imgs/logo_enidh.png" class="img-fluid col-5" alt="Enidh Logo"> 
            </div>
        </div>
        <?php
        // include modal popup to confirm collection removal
        require_once("deletePopup.php");
        // include OpenSeaMap using OpenLayers Framework
        require_once("utils/OSMOpenLayer.php");
        // include OpenSeaMap using GoogleMaps Framework (may not work properly)
        //require_once(utils/"OSMGoogleMaps.php");
        ?>
    </body>
</html>

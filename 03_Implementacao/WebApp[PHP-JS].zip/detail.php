<?php
    // check if sessions has started
    if ( !isset($_SESSION) ) {
      session_start();
    }
    // editable variables
    $logoutURL = "logout.php";
    $nonExistingTag = "N.A";
    
    // include Decimal to DMS converter
    require_once("utils/decDmsFormat.php");  
    // import MongoDB 
    require_once("libs/importMongo.php");    
    // instanciates a new client
    $username = $_SESSION["s2f-credentials"]['username'];
    $password = $_SESSION["s2f-credentials"]['password'];
    $client = new \MongoDB\Client(
        "mongodb+srv://".$username.":".$password."@clusterisel.ksoyd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
    
    // get the document given via GET
    $_INPUT_METHOD = INPUT_GET;
    $flags[] = FILTER_NULL_ON_FAILURE;
    $missionName = filter_input( $_INPUT_METHOD, 'document', FILTER_SANITIZE_STRING, $flags);
    $missionId = filter_input( $_INPUT_METHOD, 'documentId', FILTER_SANITIZE_STRING, $flags);
    
    // get the given collection from the database
    $db = $client->BoatTelemetryDB;
    $collection = $db->$missionName;
    
    // from the collection, get the specified document
    $document = $collection->findOne( ["_id" => array('$eq' => new MongoDB\BSON\ObjectId($missionId))],[] );
    
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />    
    <meta charset="UTF-8">
    <link rel="stylesheet" href="res/css/detail.css">
    <!--<script type="text/javascript" src="scripts/detail.js"></script>-->
    <title>Lista de Missões</title>
    <?php 
    require_once("scripts/imports.php"); 
    ?>
    <script type="text/javascript"> 
        function updatePlot() {
            var url = "processDetailPlot.php";

            var documentName = "<?php echo $missionName ?>"
            var documentId = "<?php echo $missionId ?>"
            
            var type = document.getElementById("inputType").value;
            var from = document.getElementById("inputFrom").value;
            var to = document.getElementById("inputTo").value;
            var datatype = document.getElementById("dataType").value

            url = url + "?type=" + type + "&from=" + from + "&to=" + to + "&data=" + datatype + "&document=" + documentName + "&documentId=" + documentId;
            
            document.getElementById("plot-image").src = url;
            document.getElementById("download-plot").href= url;
        }
    </script>
</head>

<body>
    <!-- Container com os logotipos -->	
    <div id="imgHeader" class="text-center"> 
        <img src="res/imgs/logo_isel.png" class="img-fluid mr-3" alt="Isel Logo">
        <img src="res/imgs/logo_enidh.png" class="img-fluid ml-3" alt="Enidh Logo"> 
    </div>
    <div id="center-space" class="d-flex justify-content-center align-items-center">
            <div id="center-card" class="container"> 
                <!-- Card central -->
                <div id="middle-card" class="pt-3 px-3">
                    <!-- Header Card: titulo + logout -->
                    <div id="top-card" class="container row justify-content-between">
                        <p id="titulo" class="col-6"></p>
                        <div  id="userInfo" class="col-3 justify-content-center align-items-center text-right"> 
                            <p id="subtitulo-sm">Bem vindo 
                                <span id="username">Admin</span>  
                            </p>
                            <a href="<?php echo $logoutURL ?>">Logout</a>
                        </div>
                        <div id="grey-background" class="row">
                            <!-- Table -->
                            <div id="scrollMenu" class="mt-3 mb-2 pl-3 col-12 col-md-5">
                                <table class="table table-bordered">
                                    <!-- Table Header -->
                                    <thead class="table-dark">
                                        <tr>
                                            <th scope="col">Parâmetro</th>
                                            <th scope="col">Valor</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Writes a new entry in the table for each codument in the collection -->
                                        <?php
                                        // for every value in the document
                                        foreach($document as $key => $value) {
                                            // removes "Codename", "Description" and Document ID entry from the table
                                            if($key == "Codename" || $key == "Description") { break; }
                                            echo "<tr>";
                                            // if the value is not set, changes its value
                                            if(!isset( $value ) || $value==""){
                                                $value = $nonExistingTag;
                                            }
                                            if($key == "Water"){ $key = "Água no Casco"; }
                                            // if element in document is an array
                                            if( $value instanceof MongoDB\Model\BSONArray){
                                                $arrayParam = "";
                                                foreach($value as $arrvalue) {
                                                    // if the value is not set, changes its value
                                                    if(!isset( $arrvalue ) || $arrvalue==""){
                                                        $arrvalue = $nonExistingTag;
                                                    }
                                                    $arrayParam = $arrayParam . $arrvalue . ", ";
                                                }   
                                                $arrayParam = str_split($arrayParam, strlen($arrayParam) - 2)[0];
                                                echo "<td id=\"remove-margin\"> $key </td>";
                                                echo "<td id=\"remove-margin\"> $arrayParam</td>";
                                            } else {
                                                echo "<td id=\"remove-margin\"> $key </td>";
                                                echo "<td id=\"remove-margin\"> $value </td>";
                                            }
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- Mission details -->
                            <div id="mission" class="container justify-content-between mt-3 mb-2 col-12 col-md-7">
                                <label class="highlight" for="inputType">Estilo</label>
                                <select id="inputType" class="form-control" onchange="updatePlot()">
                                    <option value="0" selected>Barras</option>
                                    <option value="1">Linhas</option>
                                </select>
                                <div id="remove-margin" class="row mt-2">
                                    <div id="remove-padding-left" class="col-12 col-md-4">
                                        <label class="highlight" for="dataType">Parâmetro:</label>
                                        <select id="dataType" class="form-control" onchange="updatePlot()">
                                            <?php
                                            $selected = "selected";
                                            foreach($document as $key => $value) {
                                                if( !($key=="_id" || $key=="Codename" || $key=="Description" || $key=="Timestamp") ) {
                                                    echo "<option value=\"$key\" $selected>$key</option>";
                                                    $selected = "";
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div> 
                                    <div  class="col-12 col-md-4">
                                        <label class="highlight" for="inputFrom">De:</label>
                                        <input type="text" class="form-control" id="inputFrom" placeholder="" onchange="updatePlot()">
                                    </div>
                                    <div id="remove-padding-right" class="col-12 col-md-4">
                                        <label class="highlight" for="inputTo">Até:</label>
                                        <input type="text" class="form-control" id="inputTo" placeholder="" onchange="updatePlot()">
                                    </div>
                                </div>
                                <img id="plot-image" src="processDetailPlot.php?type=0&from=&to=&document=<?php echo $missionName ?>&documentId=<?php echo $missionId ?>" class="img-fluid mt-3 mr-3" alt="Isel Logo" />
                                <a id="download-plot" class="btn btn-sm btn-success btn-outline text-white mt-3" href="" download="plot.png" style="float: right">
                                        <i class="fa fa-download fa-sm pr-2" aria-hidden="true"></i> Descarregar Gráfico </a>
                            </div>
                        </div>
                    </div>
                    <p id="text-footer"> Sea2Future </p>
                </div>
            </div>
            <!-- Container com os logotipos (view telemovel) -->
            <div id="imgFooter" class="d-flex row my-3 justify-content-center  align-items-center"> 
                <img src="res/imgs/logo_isel.png" class="img-fluid col-5" alt="Isel Logo">
                <img src="res/imgs/logo_enidh.png" class="img-fluid col-5" alt="Enidh Logo"> 
            </div>
        </div>
</body>
</html>


<script>
    // checks if user input was correct (=DELETE)
    function checkDelete() {
        if (document.getElementById("confirmDelete").value === "DELETE") {
            return true;
        }
        return false;
    }
</script>

<!-- Popup Modal para apagar inserir a palavra passe -->
<div class="modal fade" id="deleteModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header">
          <p id="subtitulo"> Tem a certeza que deseja apagar esta missão? </p>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal body -->
      <form action="processDeleteColection.php" method="GET" onsubmit="return checkDelete()">
        <input name="document" value="<?php echo $missionName ?>" style="display:none"/>
        <div class="modal-body">
          <div class="form-group">
              <label for="confirmDelete">Escreva <span class="highlight">"DELETE"</span> para apagar a missão.</label>
              <input type="text" required class="form-control" autocomplete="off" id="confirmDelete">
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="confirm" type="submit" value="confirm" class="btn btn-sm btn-danger btn-outline text-white">
              <i class="fa fa-trash fa-sm pr-2" aria-hidden="true"></i> Apagar missão</button>
        </div>
      </form>
    </div>
  </div>
</div>
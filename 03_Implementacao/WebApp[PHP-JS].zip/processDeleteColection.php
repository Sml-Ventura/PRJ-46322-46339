<?php
    if ( !isset($_SESSION) ) {
      session_start();
    }

    // get the collection name given via GET
    $flags[] = FILTER_NULL_ON_FAILURE;
    $missionName = filter_input( INPUT_GET, 'document', FILTER_SANITIZE_STRING, $flags);
    
    // import MongoDB 
    require_once("libs/importMongo.php");    
    // instanciates a new client
    $username = $_SESSION["s2f-credentials"]['username'];
    $password = $_SESSION["s2f-credentials"]['password'];
    $client = new \MongoDB\Client(
        "mongodb+srv://".$username.":".$password."@clusterisel.ksoyd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
    
    // get the given collection from the database
    $db = $client->BoatTelemetryDB;
    $db->dropCollection($missionName);
    
    header("Location: list.php");
    
?>

    
    
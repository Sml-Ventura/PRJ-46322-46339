<?php
    if ( !isset($_SESSION) ) {
      session_start();
    }

    // get the document given via GET
    $_INPUT_METHOD = INPUT_GET;
    $flags[] = FILTER_NULL_ON_FAILURE;
    $missionName = filter_input( $_INPUT_METHOD, 'document', FILTER_SANITIZE_STRING, $flags);
    
    // import MongoDB 
    require_once("libs/importMongo.php");    
    // instanciates a new client
    $username = $_SESSION["s2f-credentials"]['username'];
    $password = $_SESSION["s2f-credentials"]['password'];
    $client = new \MongoDB\Client(
        "mongodb+srv://".$username.":".$password."@clusterisel.ksoyd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
    
    // get the given collection from the database
    $db = $client->BoatTelemetryDB;
    $collection = $db->$missionName;
    // TODO: tudo o que está para cima é repetido, tem que ser limpo
    
    $csvFile = fopen("temp.txt", "w") or die("An error as occurred when trying to open file!");
    $txt = "Timestamp;Latitude;Longitude;AIS;ÁguaNoCasco;Corrente;Voltagem;Heading;Pitch;Roll\n";
    fwrite($csvFile, $txt);
    $documents = $collection->find([], []);
    foreach($documents as $document) {
        $txt = $document["Timestamp"].";".$document["GPS"][0].";".$document["GPS"][1].";".$document["AIS"].";".$document["Water"].";".
               $document["Corrente"].";".$document["Voltagem"].";".$document["IMU"][0].";".$document["IMU"][1].";".$document["IMU"][2]."\n";
        fwrite($csvFile, $txt);
    };
    fclose($csvFile);
    
  // clean the mission name
  $csvFileName = str_replace("_", "", $missionName);
  header('Content-Description: CSV File Transfer');
  header('Content-Type: application/octet-stream');
  header('Content-Disposition: attachment; filename=csv-'.$csvFileName.'.txt');
  header('Content-Length: ' . filesize("temp.txt"));
  header('Expires: 0');
  header('Cache-Control: must-revalidate');
  header('Pragma: public');
  readfile("temp.txt");
  exit;

    
    

function updatePlot() {
    var url = "processDetailPlot.php";
    
    var document = ""
    
    var type = document.getElementById("inputType").value;
    var from = document.getElementById("inputFrom").value;
    var to = document.getElementById("inputTo").value;
        
    url = url + "?type=" + type + "&from=" + from + "&to=" + to;
    
    //alert()
    document.getElementById("plot-image").src = url;
}

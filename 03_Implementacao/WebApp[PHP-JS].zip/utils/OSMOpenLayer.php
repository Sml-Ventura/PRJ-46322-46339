<?php
/**
 * OpenStreetMap : contributors
 * https://www.openstreetmap.org/copyright
 */
?>
<!-- bring in the OpenLayers library -->
<script src="libs/OpenLayers-2.13.1/OpenLayers.js"></script>
<!--  reverse geocodes and gets the address from the location specified on the mission. -->
<script>
    function reverseGeocode() {
        fetch('https://nominatim.openstreetmap.org/reverse?format=json&lon=' + <?php echo $lon ?> + '&lat=' + <?php echo $lat ?>)
                .then(function (response) {
                    return response.json();
                }).then(function (json) {
            // console.log(json);       // debug
            if (json["address"]["county"] != null && json["address"]["country"] != null)
                document.getElementById("location-name-<?php echo $missionName ?>").innerHTML = json["address"]["county"] + ", " + json["address"]["country"];
            else
                document.getElementById("location-name-<?php echo $missionName ?>").innerHTML = "N.A";
        });
    }
</script>
<!-- loads the map focused on the lat and lon of the first registed point. -->
<script>
    function loadOpenLayersMap() {
        map = new OpenLayers.Map("map-<?php echo $missionName ?>");
        var mapnik = new OpenLayers.Layer.OSM();
        var fromProjection = new OpenLayers.Projection("EPSG:4326");   // Transform from WGS 1984
        var toProjection = new OpenLayers.Projection("EPSG:900913");   // to Spherical Mercator Projection
        var position = new OpenLayers.LonLat(<?php echo $lon ?>,<?php echo $lat ?>).transform(fromProjection, toProjection);
        var zoom = <?php echo $osmZoom ?>;

        map.addLayer(mapnik);
        map.setCenter(position, zoom);
        
        // add markers
        var markers = new OpenLayers.Layer.Markers( "Markers" );
        map.addLayer(markers);
        
        <?php 
        if(isset($documentId)){ 
            $documents = $collection->find([], []);
            foreach ($documents as $document) { 
                $doclat = $document["GPS"][0];
                $doclon = $document["GPS"][1];
                echo "var position = new OpenLayers.LonLat(" . $doclon .",". $doclat . ").transform(fromProjection, toProjection);\n";
                echo "var mark = new OpenLayers.Marker(position);\n";
                echo "markers.addMarker(mark);\n";
                echo "mark.events.register(\"click\", mark, function(e){ window.location.href=\"detail.php?document=$missionName&documentId=$documentId\"; });\n";
            } 
        }
        ?>

        reverseGeocode();
    }
</script>


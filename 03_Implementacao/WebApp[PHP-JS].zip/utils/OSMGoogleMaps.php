<?php
/**
 * OpenStreetMap : contributors
 * https://www.openstreetmap.org/copyright
 * NOTE:
 * Using the GoogleMaps framework on the project does not create custom markers!
 */
?>
<!-- bring in the google maps library -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

<script type="text/javascript">
    //Google maps API initialisation
    var element = document.getElementById("map");

    /*
    Build list of map types.
    You can also use var mapTypeIds = ["roadmap", "satellite", "hybrid", "terrain", "OSM"]
    but static lists suck when Google updates the default list of map types.
    */
    var mapTypeIds = [];
    for (var type in google.maps.MapTypeId) {
        mapTypeIds.push(google.maps.MapTypeId[type]);
    }
    mapTypeIds.push("OSM");
    
    var map = new google.maps.Map(element, {
        center: new google.maps.LatLng(<?php echo $lat ?>, <?php echo $lon ?>),
        zoom: 17,
        mapTypeId: "OSM",
        mapTypeControlOptions: {
            mapTypeIds: mapTypeIds
        }
    });

    map.mapTypes.set("OSM", new google.maps.ImageMapType({
        getTileUrl: function (coord, zoom) {
            // See above example if you need smooth wrapping at 180th meridian
            return "https://tile.openstreetmap.org/" + zoom + "/" + coord.x + "/" + coord.y + ".png";
        },
        tileSize: new google.maps.Size(256, 256),
        name: "OpenStreetMap",
        maxZoom: 18
    }));
</script>


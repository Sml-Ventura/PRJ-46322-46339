<?php

function getDataFromCollection($documents, $from, $to, $plotType, $dataType) {
    $data = array();
    $index = 0;
    foreach($documents as $document) {
        // if the document is between the specified values (not outside de range)
        if(! ($index < $from || $index > $to) ){
            $push = array($document["Timestamp"]);
            // if it is an array, insert all values
            if( $document[$dataType] instanceOf \MongoDB\Model\BSONArray ){
                foreach($document[$dataType] as $value) {
                    array_push($push, floatval($value));
                }
            } else {
                array_push($push, floatval($document[$dataType]));
            }
            // push the new entry to the data array
            array_push($data, $push);
        }
        $index++; 
    }
    return $data;
}

/**
 * Creates a 'Line' Plot with the given $data
 */
function plotLines($plot, $data) {
    $plot->SetPlotType('lines');

    $plot->SetDataValues($data);

    //Turn off X axis ticks and labels because they get in the way:
    $plot->SetXTickLabelPos('none');
    $plot->SetXTickPos('none');
    
    return $plot;
}

/**
 * Creates a 'Bars' Plot with the given $data
 */
function plotBars($plot, $data){
    $plot->SetPlotType('bars');
    $plot->SetDataType('text-data');
    $plot->SetDataValues($data);
    
    # Force bottom to Y=0 and set reasonable tick interval:
    $plot->SetYLabelType('data');
    $plot->SetPrecisionY(0);

    # Turn off X tick labels and ticks because they don't apply here:
    $plot->SetXTickLabelPos('none');
    $plot->SetXTickPos('none');

    return $plot;
}
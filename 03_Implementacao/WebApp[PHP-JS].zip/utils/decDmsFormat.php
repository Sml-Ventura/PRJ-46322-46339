<?php

function dec_dms($dec) {
  $vars = explode(".", $dec);
  $deg = $vars[0];
  $tempma = '0.' . $vars[1];
  
  $tempma = $tempma * 3600;
  $min = floor($tempma / 60);
  $sec = $tempma - ($min * 60);
  
 return array('deg' => $deg, 'min' => $min, 'sec' => $sec);
}

function lat_lng($lat, $lng) {
   $latpos = (strpos($lat, '-') !== false) ? 'S' : 'N';
   $lat = dec_dms($lat);
   $lngpos = (strpos($lng, '-') !== false) ? 'W' : 'E';
   $lng = dec_dms($lng);

   return abs($lat['deg']) . '&deg;' . $lat['min'] . '&apos;' . $lat['sec'] . '&quot' . $latpos . "<br>" . abs($lng['deg']) . '&deg;' . $lng['min'] . '&apos;' . $lng['sec'] . '&quot' . $lngpos ;
}

?>

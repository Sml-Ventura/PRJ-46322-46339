<?php
    session_start();
    session_destroy();

    $logoutURL = "authentication.php";
    echo "<META HTTP-EQUIV=\"refresh\" CONTENT=\"2; URL=". $logoutURL ."\">";
?>
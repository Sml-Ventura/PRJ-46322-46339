<?php

// gets the user requested URI to save
$flags[] = FILTER_NULL_ON_FAILURE;
$uri = filter_input( INPUT_SERVER, 'REQUEST_URI', FILTER_SANITIZE_URL, $flags);

// starts session
if ( !isset( $_SESSION ) ) {
    session_start();
}

// if the user is not set, redirect to the authentication and save the location
if ( !isset( $_SESSION[ 'username' ] ) ) {
    $_SESSION['locationAfterAuth'] = $uri;
    header( "Location: authentication.php" );
    exit;
}
?>
<!DOCTYPE html>
<?php
    $EnidhLink = "https://www.enautica.pt/pt/enidh/noticias-23/projeto-enidh-sea2future-590";
    $nextUrl = "processAuthentication.php";
            
    if ( !isset($_SESSION) ) {
      session_start();
    }     
    if ( isset($_SESSION["s2f-credentials"]) ) {
        header("Location: processAuthentication.php");
    } 
?>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta charset="UTF-8">
    <link rel="stylesheet" href="res/css/home.css">
    <title>Página de Entrada</title>
    <?php require_once("scripts/imports.php"); ?>
</head>

<body>
    <!-- Seccao central -->
    <div id="center-space" class="d-flex justify-content-center align-items-center">
        <div id="center-card" class="container"> 
            <!-- Container com os logotipos -->
            <div id="imgHeader" class="text-center"> 
                <img src="res/imgs/logo_isel.png" class="img-fluid " alt="Isel Logo">
                <img src="res/imgs/logo_enidh.png" class="img-fluid" alt="Enidh Logo"> 
            </div>
            <!-- Titulo e Subtitulo -->
            <div class="text-center">
                <p id="titulo">Sea2Future</p>
                <p id="subtitulo">Aplicação para Acesso à Base de Dados</p>
            </div>
            <!-- Card central -->
            <div id="card" class="row container text">
                <div id="left-space" class="col-0 col-sm-0 col-md-1 col-lg-2 col-xl-3"> &nbsp; </div>
                <div id="middle-card" class="col-12 col-sm-12 col-md-10 col-lg-8 col-xl-6">
                    <!-- Paragrafo de Texto -->
                    <p id="paragraph">&emsp; <span class="highlight">Sea2Future</span> é um projeto lançado pela ENIDH que consiste no desenvolvimento de uma embarcação de controlo remoto capaz de telemetria.<br>
                        &emsp;Em parceria com o ISEL, desenvolveu-se um módulo de análise e processamento de dados dos sensores, para os armazenar e demonstrar nesta aplicação.<br>
                        &emsp;Clique no <a href="<?php echo $EnidhLink ?>">link</a> para mais informações do projeto. </p>
                    <hr class="mx-3" style="border: 1px solid #0240575d;">
                    <!-- Form de Login -->
                    <form action="<?php echo $nextUrl ?>" method="POST">
                        <!-- Utilizador -->
                        <div class="form-outline form-white my-3">
                            <label for="userInput" id="inputText"> Nome de Acesso </label>
                            <div class="form-group has-search">
                                <span class="fa fa-lg fa-user-circle form-control-feedback"></span>
                                <input required autocomplete="off" name="userInput" id="userInput" type="userInput" class="form-control" placeholder="Insira o nome de utilizador"/>
                            </div>
                        </div>
                        <!-- Password -->
			<div class="form-outline form-white my-3">
                            <label for="userInput" id="inputText"> Password </label>
                            <div class="form-group has-search">
                                <span class="fa fa-lg fa-key form-control-feedback"></span>
                                <input required autocomplete="off" name="passwordInput" id="passwordInput" type="password" class="form-control" placeholder="Insira a palavra chave"/>
                            </div>
                        </div>
                        <?php if(isset($_SESSION["failed"]) && isset($_SESSION["failed"]) == true) {
                            $_SESSION["failed"] = null;
                            echo "<p id=\"danger-text\"> O nome ou palavra-chave introduzidos estão incorretos. <br> Verifique se estes foram escritos corretamente. </p>"; }
                        ?>
			<!-- Botao para login -->
                        <div class="text-center">
                            <button class="button" type="submit"><span>Entrar</span></button>
                        </div>
                    </form>
                </div>
                <div id="left-space" class="col-0 col-sm-0 col-md-1 col-lg-2 col-xl-3"> &nbsp; </div>
            </div>
            <div id="imgFooter" class="d-flex row my-3 justify-content-center  align-items-center"> 
                <img src="res/imgs/logo_isel.png" class="img-fluid col-5" alt="Isel Logo">
		<img src="res/imgs/logo_enidh.png" class="img-fluid col-5" alt="Enidh Logo"> 
            </div>
        </div>
    </div>
</body>
</html>
# Configuration Scripts for End-to-end Testing

These scripts were taken from [mongo-enterprise-modules](https://github.com/10gen/mongo-enterprise-modules/tree/master/jstests/external_auth_aws) 
and intended to simplify creating users, attaching roles to existing EC2 instances, launching an Amazon ECS container instance, etc.
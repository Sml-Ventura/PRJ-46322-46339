<?php
    $basePath = "mongodb/src/";

    // imports the base interfaces from MongoDB Library
    require_once($basePath . "Exception/Exception.php");
    require_once($basePath . "Exception/RuntimeException.php");
    require_once($basePath . "Exception/InvalidArgumentException.php");
    require_once($basePath . "Model/CollectionInfoIterator.php");
    require_once($basePath . "Operation/Executable.php");
    require_once($basePath . "Operation/Explainable.php");
    require_once($basePath . "Command/ListDatabases.php");
    require_once($basePath . "Command/ListCollections.php");
    
    // imports every file from src at MongoDB Library
    foreach (glob("libs/". $basePath ."*.php") as $filename) {
        require_once($filename);
    }
    // imports every file from src.Exception at MongoDB Library
    foreach (glob("libs/". $basePath ."Exception/*.php") as $filename) {
        include_once($filename);
    }

    // imports every file from src.Operation at MongoDB Library
    foreach (glob("libs/". $basePath ."Operation/*.php") as $filename) {
        require_once($filename);
    }
    
        // imports every file from src.Operation at MongoDB Library
    foreach (glob("libs/". $basePath ."Model/*.php") as $filename) {
        require_once($filename);
    }


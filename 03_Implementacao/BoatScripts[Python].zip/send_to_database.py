import json
import os

from pymongo import MongoClient


def send_to_db(data, upload_to_cloud, mission_num, codename, description):
    # fazer a verificacao para ver se tem internet ou nao
    bad_connection = check_connection(data["signal_quality"])

    # se for a primeira execucao deste script
    if mission_num == -1:
        # determinar o numero da missao
        mission_num = get_mission_num()
        # criar o json local
        create_json("tmp/mission" + str(mission_num) + ".json")

    if upload_to_cloud and not bad_connection:
        # armazenar remotamente
        # recolher os dados que estejam guardados localmente
        if os.path.exists("tmp/mission" + str(mission_num) + ".json"):
            file_path = "tmp/mission" + str(mission_num) + ".json"
            with open(file_path) as json_file:
                stored_data = json.load(json_file)
                stored_data = stored_data["mission_details"]
        # envio dos dados locais
        for entry in stored_data:
            upload_data(entry, mission_num)
        # envio dos novos dados
        upload_data(data, mission_num, codename, description)
        # esvaziar o ficheiro local para otimizar espaco
        create_json("tmp/mission" + str(mission_num) + ".json")
    else:
        # armazenar localmente
        file_path = "tmp/mission" + str(mission_num) + ".json"
        update_json(data, file_path)
    return mission_num


def upload_data(data_to_upload, mission_num, codename=None, description=None):
    # ligacao ao MongoDB
    client = MongoClient(
        "mongodb+srv://admin:conchinha123@clusterisel.ksoyd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")

    my_db = client["BoatTelemetryDB"]

    my_collection = my_db["Mission" + str(mission_num)]


    if codename and description is not None:
        # se forem os dados novos
        data_to_send = {"Timestamp": "" + data_to_upload["reg_time"], "GPS": data_to_upload["fix"],
                    "IMU": (data_to_upload["hdg"], data_to_upload["pitch"], data_to_upload["roll"]),
                    "AIS": data_to_upload["AIS"], "Corrente": data_to_upload["current"],
                    "Voltagem": data_to_upload["voltage"],
                    "Water": data_to_upload["humidity"],
                    "Codename": codename,
                    "Description": description}
    else:
        # se forem os dados locais
        data_to_send = {"Timestamp": "" + data_to_upload["reg_time"], "GPS": data_to_upload["fix"],
                        "IMU": (data_to_upload["hdg"], data_to_upload["pitch"], data_to_upload["roll"]),
                        "AIS": data_to_upload["AIS"], "Corrente": data_to_upload["current"],
                        "Voltagem": data_to_upload["voltage"],
                        "Water": data_to_upload["humidity"]}

    my_collection.insert_one(data_to_send)


def check_connection(signal_quality):
    return signal_quality < 30


def update_json(new_data, file_name):
    with open(file_name, 'r+') as file:
        file_data = json.load(file)
        file_data["mission_details"].append(new_data)
        file.seek(0)
        json.dump(file_data, file, indent=4)


def create_json(file_name):
    with open(file_name, "w") as file:
        main_struct = {"mission_details": []}
        json.dump(main_struct, file)


def get_mission_num():
    mission_index = 0
    while os.path.exists("tmp/mission%s.json" % mission_index):
        mission_index += 1
    return mission_index
